import io
import cv2
import numpy as np
from PIL import Image
import streamlit as st
import fitz  # PyMuPDF
from main import extract_text_and_images_from_pdf
def save_text_to_file(texts, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        for i, text in enumerate(texts):
            file.write(f"第 {i+1} 页的文本:\n")
            file.write(text + "\n\n")
# Streamlit 界面
st.title("PDF 文本和图片提取器")

# 上传文件
uploaded_file = st.file_uploader("上传一个 PDF 文件", type="pdf")

if uploaded_file is not None:
    # 提取文本和图片
    output_folder = "extracted_images"
    texts, images = extract_text_and_images_from_pdf(uploaded_file, output_folder)
    save_text_to_file(texts, "extracted_texts.txt")
    # 显示文本
    for i, text in enumerate(texts):
        st.write(f"第 {i+1} 页的文本:")
        st.write(text)


    # 显示图片
    for i, image_path in enumerate(images):
        st.write(f"第 {i+1} 页的图片:")
        st.image(image_path)
