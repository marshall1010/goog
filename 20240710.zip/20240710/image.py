import base64
import requests
from openai import OpenAI
import os
import json

# OpenAI API Key
api_key = "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"
def save_image_to_file(images, file_path):
    # 将字典转换为 JSON 格式的字符串
    images_json = json.dumps(images, ensure_ascii=False, indent=4)

    # 将字符串写入文件
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(images_json)
def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

# Path to your images folder
images_folder = "extracted_images"

# Getting the paths of all images in the folder
image_paths = [os.path.join(images_folder, f) for f in os.listdir(images_folder) if os.path.isfile(os.path.join(images_folder, f))]

# Getting the base64 strings for each image
base64_images = [encode_image(image_path) for image_path in image_paths]

headers = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {api_key}"
}

# Constructing the messages payload with multiple images
messages = []
for index, base64_image in enumerate(base64_images):
    messages.append({
        "role": "user",
        "content": [
            {
                "type": "text",
                "text": f"What’s in this image {index + 1}?"
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpg;base64,{base64_image}"
                }
            }
        ]
    })

payload = {
    "model": "gpt-4o",
    "messages": messages,
    "max_tokens": 300
}

response = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
print("### RESPONSE CONTENT IS HERE ###")
print(response.choice[0])
# Print and save the response
# response_content = response.json()
# print(response_content)
# save_image_to_file(response_content , "extracted_image.txt")

# Save the response to a .txt file
with open("extracted_image.txt", "w", encoding="utf-8") as file:
    json.dump(response_content, file, ensure_ascii=False, indent=4)


