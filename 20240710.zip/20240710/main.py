import fitz  # PyMuPDF
import io
from PIL import Image
import cv2
import numpy as np
import sys
import os
def extract_text_and_images_from_pdf(pdf_path, output_folder):
    text_content = []
    image_content = []
    doc = fitz.open(pdf_path)

    # Create the output folder if it does not exist
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        
        # Extract text
        text_content.append(page.get_text())
        
        # Extract images
        images = page.get_images(full=True)
        for img_index, img in enumerate(images):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            image = Image.open(io.BytesIO(image_bytes))
            
            # Save image to the output folder
            image_filename = f"page_{page_num+1}_image_{img_index+1}.jpg"
            image_path = os.path.join(output_folder, image_filename)
            image.save(image_path)
            image_content.append(image_path)

    return text_content, image_content
sys.stdout.reconfigure(encoding='utf-8')
# Usage
def text_and_images_display(pdf_path):
    pdf_path = " "
    output_folder = "extracted_images"
    texts, images = extract_text_and_images_from_pdf(pdf_path, output_folder)
    return texts, images
